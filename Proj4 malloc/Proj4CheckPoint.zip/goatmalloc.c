#include <stdio.h>
#include <stddef.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

#include "goatmalloc.h"
#include "goatmalloc.h"


/////////////
// GLOBALS //
/////////////

void* _arena_start;
int statusno;
int max_mem;

/////////////
// STRUCTS //
/////////////

/*typedef struct {
	int size;
	int magic;
} header_t;*/


// init //
int init(size_t size) {
	int arena_size = 0;
	//int found_free = 0;
	// initializes memory allocator
	printf("Initializing arena:\n");
	printf("...requested size %zu bytes\n", size);
	printf("...pagesize is %zu bytes\n", size);
	int fd = open("/dev/zero", O_RDWR);
	if (size > 10000000) return ERR_BAD_ARGUMENTS;

	printf("...adjusting size with page boundaries\n");
	if(size < getpagesize()) {
		size = getpagesize();
	} else if (size > getpagesize()) {
		size += getpagesize() - (size % getpagesize());
	}
	printf("...adjusted size is %zu bytes\n", size);

	printf("...mapping arena with mmap()\n");

	//int pos = 0;
	//header_t *header;
	node_t *chunk;

	if(_arena_start == NULL) {

		_arena_start = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
		printf("...arena starts at %p\n", _arena_start);
		//chunk = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
		chunk = _arena_start;
		//header = chunk;
		//header->size = size;

		arena_size += size;
		//chunk->size = size - sizeof(node_t);
		chunk->size = size;
		chunk->fwd = NULL;

	} else {

		printf("...arena starts at %p\n", _arena_start);
		node_t *tmp;
		//node_t *prev;
		tmp = _arena_start;
		arena_size += tmp->size;
		/*if(tmp->is_free == 1) {
			return arena_size;
		}*/

		while(tmp->fwd != NULL) {
			tmp = tmp->fwd;
			arena_size += tmp->size;
			/*if(tmp->is_free == 1) {
				found_free = 1;
			}*/

		}

		/*if(found_free) {
			return arena_size;
		}*/

		//tmp->bwd = prev;

		chunk = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);

		tmp->fwd = chunk;

		chunk->size = size;
		chunk->bwd = tmp;
		chunk->fwd = NULL;

		arena_size += chunk->size;
		
	}

	printf("...arena ends at %p\n", chunk+(size/sizeof(node_t)));

	printf("...initializing header for initial free chunk\n");
	//header = _arena_start;
	printf("...header size is %zu bytes\n", sizeof(chunk));
	chunk->is_free = 1;
	
	max_mem = arena_size;
	return arena_size;

}


int destroy() {
	//returns area's mem to OS and reset all internal state variables
	if(_arena_start == NULL) return ERR_UNINITIALIZED;
	node_t *chunk = _arena_start;
	printf("Destroying Arena:\n");
	printf("...unmapping arena with munmap()\n");
	//munmap(_arena_start, chunk->size);
	munmap((_arena_start+chunk->size)-max_mem, max_mem);
	_arena_start = NULL;

	return 0;

}


void* walloc(size_t size) {
	//int offset;
	int found_free = 0;
	// requests new memory allocation of size bytes
	printf("Allocating memory:\n");

	if (_arena_start == NULL) {
		statusno = ERR_UNINITIALIZED;
		return NULL;

	}

	node_t *tmp;

	printf("...looking for free chunk of >= %zu bytes\n", size);

	size += sizeof(node_t);

	tmp = _arena_start;
	if(tmp->is_free == 1 && tmp->size >= size){
		found_free = 1;

	} else {

		while(tmp->fwd != NULL) {
			tmp = tmp->fwd;
			if(tmp->is_free == 1 && tmp->size >= size) {
				found_free = 1;
				break;
			}
		}
	}


	/*if(!found_free) {
		offset = init(size+sizeof(node_t));
		tmp = _arena_start - offset;
		// find last elem
		// set that equal to tmp or something

		//_arena_start - offset;

	}*/

	if (!found_free) {
		statusno = ERR_OUT_OF_MEMORY;
		return NULL;

	}

	tmp->is_free = 0;

	printf("...found free chunk of %zu bytes with header at %p\n", tmp->size, tmp);

	printf("...free chunk->fwd currently points to %p\n", tmp->fwd);
	printf("...free chunk->bwd currently points to %p\n", tmp->bwd);

	//printf("...checking if splitting is required\n");
	//printf("...splitting not required\n");
	//printf("...updating chunk header at %p\n",);
	//printf("...being careful with my pointer arithmetic and void poitner casting\n");
	//printf("...allocation starts at %p\n");

	//return tmp + sizeof(node_t)/sizeof(node_t);
	return tmp + 1;
}


void wfree(void *ptr) {
	// free  up existing memory chunks
	printf("Freeing allocated memory:\n");
	printf("...supplied pointer %p\n", ptr);
	printf("...being careful with my pointer arithmetic and void pointer casting\n");
	
	node_t *tmp = ptr - sizeof(node_t);

	printf("...accessing chunk header at %p\n", tmp);
	printf("...chunk of size %zu\n", tmp->size);

	tmp->is_free = 1;
	tmp->size -= sizeof(node_t);

	//printf("...checking if coalescing is needed\n");
	//printf("...coalescing not needed.\n");

}

#define PRINTF_GREEN(...) fprintf(stderr, "\033[32m"); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\033[0m");

/*int main(int argc, char **args) {

	return 0;
}*/
