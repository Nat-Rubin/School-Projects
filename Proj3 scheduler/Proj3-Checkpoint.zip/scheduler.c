#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <limits.h>



// TODO: Add more fields to this struct
struct job {
    int id;
    int arrival;
    int length;
    struct job *next;
};

/*** Globals ***/ 
int seed = 100;
int time;

//This is the start of our linked list of jobs, i.e., the job list
struct job *head = NULL;

/*** Globals End ***/

/*Function to append a new job to the list*/
void append(int id, int arrival, int length){
  // create a new struct and initialize it with the input data
  struct job *tmp = (struct job*) malloc(sizeof(struct job));

  //tmp->id = numofjobs++;
  tmp->id = id;
  tmp->length = length;
  tmp->arrival = arrival;

  // the new job is the last job
  tmp->next = NULL;

  // Case: job is first to be added, linked list is empty 
  if (head == NULL){
    head = tmp;
    return;
  }

  struct job *prev = head;

  //Find end of list 
  while (prev->next != NULL){
    prev = prev->next;
  }

  //Add job to end of list 
  prev->next = tmp;
  return;
}


/*Function to read in the workload file and create job list*/
void read_workload_file(char* filename) {
  int id = 0;
  FILE *fp;
  size_t len = 0;
  ssize_t read;
  char *line = NULL,
       *arrival = NULL, 
       *length = NULL;

  //struct job **head_ptr = malloc(sizeof(struct job*));

  if( (fp = fopen(filename, "r")) == NULL)
    exit(EXIT_FAILURE);

  while ((read = getline(&line, &len, fp)) > 1) {
    arrival = strtok(line, ",\n");
    length = strtok(NULL, ",\n");
       
    // Make sure neither arrival nor length are null. 
    assert(arrival != NULL && length != NULL);
        
    append(id++, atoi(arrival), atoi(length));
  }

  fclose(fp);

  // Make sure we read in at least one job
  assert(id > 0);

  return;
}

//void printJobInfo(int num; int arrive; int time)
void printJobInfo(struct job *job) {
  printf("t=%i: [Job %i] arrived at [%i], ran for: [%i]\n", time, job->id, job->arrival, job->length);
}

void policy_FIFO(struct job *head) {
  // TODO: Fill this in

  printf("Execution trace with FIFO:\n");

  /*// Find the number of jobs
  struct job *prev = head;
  int num_jobs = 0;
  while(prev->next != NULL) {
    prev = prev->next;
  }*/

  struct job *prev = head;

  while(1) {

    printJobInfo(prev);
    time += prev->length;

    if(prev->next == NULL) break;
    prev = prev->next;

  }

  printf("End of execution with FIFO.\n");

  return;
}


void analyze_FIFO(struct job *head) {
  // TODO: Fill this in

  return;
}


void policy_SJF(struct job *head) {
  printf("Execution trace with SJF:\n");
  int total = 0;
  int shortest;
  int idle;

  struct job *prev = head;

  while(1) {
    total++;

    if(prev->next == NULL) break;
    prev = prev->next;

  }

  prev = head;
  
  struct job *jobs = malloc(total*sizeof(*jobs));

    int i = 0;
    while(1) {
      //jobs[i] = prev;
      jobs[i].id = prev->id;
      jobs[i].arrival = prev->arrival;
      jobs[i].length = prev->length;
      jobs[i].next = prev->next;

      if(prev->next == NULL) break;

      prev = prev->next;
      i++;

    }


    shortest = 0;
    int counter = 0;
    while(counter < total) {

      idle = 1;
      for(i = 0; i < total; i++) {

        if(i == 0 && counter == 0) {
          idle = 0;
        }

        if(jobs[i].arrival != -1) {
          if(jobs[i].arrival <= time) {
            if(jobs[i].length < jobs[shortest].length) {
              shortest = i;
              idle = 0;
            }

          }

        }

      }
      

    
      if(idle == 1) {
        time++;
        continue;
      }

      printJobInfo(&jobs[shortest]);
      time += jobs[shortest].length;
      jobs[shortest].arrival = -1;
      jobs[shortest].length = INT_MAX;
      counter++;

    }
    printf("End of execution with SJF.\n");

}


int main(int argc, char **argv) {
  time = 0;

 if (argc < 4) {
    fprintf(stderr, "missing variables\n");
    fprintf(stderr, "usage: %s analysis-flag policy workload-file slice-duration\n", argv[0]);
		exit(EXIT_FAILURE);
  }

  int analysis = atoi(argv[1]);
  char *policy = argv[2],
       *workload = argv[3];
  //int slice_duration = atoi(argv[4]);

  // Note: we use a global variable to point to 
  // the start of a linked-list of jobs, i.e., the job list 
  read_workload_file(workload);

  if (strcmp(policy, "FIFO") == 0 ) {
    policy_FIFO(head);
    if (analysis) {
      printf("Begin analyzing FIFO:\n");
      analyze_FIFO(head);
      printf("End analyzing FIFO.\n");
    }

    exit(EXIT_SUCCESS);
  }

  // TODO: Add other policies

  if(!strcmp(policy, "SJF")) {
    policy_SJF(head);
  }

	exit(EXIT_SUCCESS);
}
